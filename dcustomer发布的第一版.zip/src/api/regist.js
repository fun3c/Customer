import httpAxios from '@/utils/request'
export default {
    regist(params){
        return httpAxios.post("******",params)
    }
}
//注册